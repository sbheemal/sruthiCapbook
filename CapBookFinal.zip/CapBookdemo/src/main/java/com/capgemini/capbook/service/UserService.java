package com.capgemini.capbook.service;

import java.util.List;

import com.capgemini.capbook.dao.IUserDao;
import com.capgemini.capbook.bean.UserProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("userService")
public class UserService implements IUserService {

	@Autowired
	private IUserDao userDao;
	
	@Override
	public UserProfile getUserDetails(String email) {
		return (UserProfile) userDao.searchUser(email);
	}

}
