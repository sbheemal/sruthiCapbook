package com.capgemini.capbook.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capbook.bean.Friend;
import com.capgemini.capbook.service.ICapBookService;


@RestController
@RequestMapping("/frnd")
@CrossOrigin("*")
public class AddFriendController {
	
	//private String label="AddFriend";

	@Autowired
	private ICapBookService friendservice;
	
	@RequestMapping(value="/addFriend",method=RequestMethod.GET)
	ResponseEntity<Friend> addFriend(@RequestParam("receiverId") String toUserId) {
				return null;	
}
	
	@PostMapping(value="/friend")
	ResponseEntity<List<Friend>> saveFriend(@RequestBody Friend friend){
		List<Friend> friend1= friendservice.saveFriend(friend);
		if(friend1.isEmpty())
		{
			return new ResponseEntity("Sorry! unable to add friends",HttpStatus.NOT_FOUND); 
		}
		
		return new ResponseEntity<List<Friend>>(friend1, HttpStatus.OK);
	}
	@GetMapping(value="/friend")
	ResponseEntity<List<Friend>> getFriend(){
		List<Friend> friend1= friendservice.getFriend();
		if(friend1.isEmpty())
		{
			return new ResponseEntity("Sorry! unable to add friends",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Friend>>( friend1, HttpStatus.OK);
	}
}