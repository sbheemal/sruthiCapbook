package com.capgemini.capbook.controller;

import com.capgemini.capbook.bean.Login;

import com.capgemini.capbook.bean.UserProfile;
import com.capgemini.capbook.service.ICapBookService;
import com.capgemini.capbook.service.ILoginService;
import com.capgemini.capbook.service.IUserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/L")
public class UserController {
	@Autowired
	private ILoginService loginService;
	@Autowired
	private ICapBookService friendservice;
	@Autowired
	private IUserService userService;

	@GetMapping("/login/{email}/{password}")
	public ResponseEntity<UserProfile> checkLogin( @PathVariable("email") String email,@PathVariable("password") String password){
	Login login=  friendservice.findByUsername(email);
      System.out.println(login);
		if(loginService.checkUser(login)) {
			UserProfile users= userService.getUserDetails(login.getEmail());
			System.out.println(users);
			if(users==null)
				return new ResponseEntity("Error Fetching User Details",HttpStatus.NOT_FOUND);
			return new ResponseEntity<UserProfile>(users, HttpStatus.OK);
		}
		return new ResponseEntity("Invalid Credentials",HttpStatus.NOT_FOUND);
	} 
	/*@GetMapping("/login")
	public ResponseEntity<UserProfile> getLogin(@RequestBody Login login ) {
         if(loginService.getAlllogins()==null) {
        	 return 
         }
		
		return new ResponseEntity("Invalid Credentials",HttpStatus.NOT_FOUND);
	} */

}
